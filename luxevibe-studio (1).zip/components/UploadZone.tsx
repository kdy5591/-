
import React, { useRef, useState } from 'react';
import { Upload, Plus, Sparkles, Image as ImageIcon } from 'lucide-react';

interface UploadZoneProps {
  onUpload: (file: File) => void;
  isAnalyzing: boolean;
}

export const UploadZone: React.FC<UploadZoneProps> = ({ onUpload, isAnalyzing }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      onUpload(files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      onUpload(files[0]);
    }
  };

  return (
    <div id="upload" className="relative py-32 px-8">
      {/* Background Decorative Element */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#d4af37]/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl serif mb-4 italic font-light">Submission</h2>
          <p className="text-[10px] uppercase tracking-[0.5em] text-gray-500">당신의 찰나를 예술적 서사로 변환합니다</p>
        </div>

        <div 
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`relative glass-panel rounded-[40px] p-2 transition-all duration-700 glow-hover group cursor-pointer
            ${isDragging ? 'scale-105 border-[#d4af37]/40' : ''}
            ${isAnalyzing ? 'pointer-events-none opacity-80' : ''}
          `}
        >
          <div className="relative border border-white/5 rounded-[38px] h-[450px] flex flex-col items-center justify-center overflow-hidden">
            {/* Animated Grid Background */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black,transparent)]"></div>

            <input 
              type="file" 
              className="hidden" 
              ref={fileInputRef} 
              accept="image/*"
              onChange={handleFileChange}
            />
            
            {isAnalyzing ? (
              <div className="flex flex-col items-center z-10">
                <div className="relative mb-8">
                    <div className="absolute inset-0 bg-[#d4af37]/20 blur-2xl rounded-full animate-pulse"></div>
                    <Sparkles className="w-16 h-16 text-[#d4af37] animate-spin-slow" style={{ animationDuration: '8s' }} />
                </div>
                <p className="text-2xl serif italic text-white/90">지적인 큐레이팅 중...</p>
                <div className="mt-4 flex space-x-1">
                    <div className="w-1 h-1 bg-[#d4af37] rounded-full animate-bounce"></div>
                    <div className="w-1 h-1 bg-[#d4af37] rounded-full animate-bounce [animation-delay:0.2s]"></div>
                    <div className="w-1 h-1 bg-[#d4af37] rounded-full animate-bounce [animation-delay:0.4s]"></div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center z-10 group-hover:transform group-hover:scale-105 transition-transform duration-700">
                <div className="w-20 h-20 mb-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-[#d4af37]/10 group-hover:border-[#d4af37]/30 transition-all duration-500">
                  <Plus className="w-8 h-8 text-white/30 group-hover:text-[#d4af37]" />
                </div>
                <h3 className="text-3xl font-light mb-4 text-white/80 tracking-tight">당신의 마스터피스를 선택하세요</h3>
                <p className="text-gray-500 text-xs uppercase tracking-[0.3em] font-medium">또는 이 감각적인 공간으로 이미지를 드래그하세요</p>
                
                <div className="mt-12 flex items-center space-x-6 text-[10px] uppercase tracking-widest text-gray-600">
                    <span className="flex items-center"><ImageIcon className="w-3 h-3 mr-2" /> PNG / JPG</span>
                    <span className="w-1 h-1 bg-gray-800 rounded-full"></span>
                    <span>최대 10MB</span>
                </div>
              </div>
            )}
            
            {/* Subtle corner accents */}
            <div className="absolute top-8 left-8 w-4 h-4 border-t border-l border-white/10"></div>
            <div className="absolute top-8 right-8 w-4 h-4 border-t border-r border-white/10"></div>
            <div className="absolute bottom-8 left-8 w-4 h-4 border-b border-l border-white/10"></div>
            <div className="absolute bottom-8 right-8 w-4 h-4 border-b border-r border-white/10"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
