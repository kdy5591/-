
export interface ShowcaseImage {
  id: string;
  url: string;
  title: string;
  description: string;
  timestamp: number;
}

export interface AIAnalysisResult {
  title: string;
  description: string;
}
