
import React from 'react';

export const ProcessSection: React.FC = () => {
  const processes = [
    {
      id: '01',
      name: 'Vision',
      desc: '우리는 당신의 일상 속 파편화된 순간들을 포착하여 하나의 미학적 줄거리를 구성합니다.'
    },
    {
      id: '02',
      name: 'Analysis',
      desc: '최첨단 AI 큐레이터가 이미지의 구도와 조명, 감각적 깊이를 분석하여 가치를 부여합니다.'
    },
    {
      id: '03',
      name: 'Curation',
      desc: '단순한 저장을 넘어, 당신의 아카이브가 하나의 예술적 서사가 되도록 정교하게 큐레이팅합니다.'
    },
    {
      id: '04',
      name: 'Expansion',
      desc: '뚬뚜미의 볼쌀을 물어주구 뽈따구를 아주그냥 씨게 뜯어줄겁니다.'
    }
  ];

  return (
    <section className="py-32 px-8 bg-[#0a0a0a] border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20 text-center md:text-left">
          <h2 className="text-4xl md:text-6xl font-bold serif text-white tracking-tighter uppercase mb-4">
            Our <span className="gold-text italic">Methodology</span>
          </h2>
          <div className="w-16 h-px bg-[#d4af37] mx-auto md:mx-0"></div>
        </div>

        <ul className="border-t border-white/5">
          {processes.map((proc) => (
            <li 
              key={proc.id}
              className="group flex flex-col md:flex-row justify-between items-start md:items-center py-16 px-6 border-b border-white/5 transition-all duration-700 hover:bg-white/[0.02] hover:px-10 cursor-default"
            >
              <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-12">
                <span className="text-[10px] font-black tracking-[0.5em] text-[#d4af37] opacity-60">
                  {proc.id}.
                </span>
                <span className="text-4xl md:text-6xl font-light uppercase serif italic text-white/90 tracking-tighter group-hover:text-white transition-colors">
                  {proc.name}
                </span>
              </div>
              
              <p className="mt-6 md:mt-0 text-left md:text-right md:max-w-md text-sm text-gray-500 font-light leading-relaxed break-keep group-hover:text-gray-400 transition-colors">
                {proc.desc}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};
