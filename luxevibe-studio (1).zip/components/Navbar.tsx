
import React from 'react';

export const Navbar: React.FC = () => {
  const scrollToCollection = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const element = document.getElementById('collection');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-8 py-6 flex justify-between items-center glass-panel">
      <div className="flex items-center space-x-2">
        <span className="text-2xl font-bold tracking-tighter serif italic text-white">
          뚬<span className="gold-text">뚜미</span>
        </span>
      </div>
      <div className="hidden md:flex space-x-16 text-[14px] tracking-[0.2em] font-medium text-gray-400 serif italic">
        <a 
          href="#collection" 
          onClick={scrollToCollection}
          className="hover:text-[#d4af37] transition-colors cursor-pointer"
        >
          이수미
        </a>
        <a 
          href="#collection" 
          onClick={scrollToCollection}
          className="hover:text-[#d4af37] transition-colors cursor-pointer"
        >
          뚬뚜미
        </a>
        <a 
          href="#collection" 
          onClick={scrollToCollection}
          className="hover:text-[#d4af37] transition-colors cursor-pointer"
        >
          민둥이
        </a>
      </div>
      <div>
        <button className="px-6 py-2 border border-[#d4af37]/40 text-[#d4af37] text-[10px] font-bold uppercase tracking-widest hover:bg-[#d4af37] hover:text-black transition-all duration-500 rounded-full">
          Inquire
        </button>
      </div>
    </nav>
  );
};
