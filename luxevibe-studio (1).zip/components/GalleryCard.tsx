
import React from 'react';
import { ShowcaseImage } from '../types';

interface GalleryCardProps {
  image: ShowcaseImage;
}

export const GalleryCard: React.FC<GalleryCardProps> = ({ image }) => {
  return (
    <div className="group relative break-inside-avoid mb-16 animate-fade-in bg-white/5 p-4 rounded-3xl border border-white/5 hover:border-[#d4af37]/20 transition-all duration-700 glow-hover">
      <div className="relative overflow-hidden rounded-2xl bg-black/40">
        <img 
          src={image.url} 
          alt={image.title} 
          className="w-full grayscale group-hover:grayscale-0 transition-all duration-[1s] ease-out transform group-hover:scale-110"
        />
        
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>
      </div>
      
      <div className="mt-8 px-2">
        <div className="flex justify-between items-start mb-4">
            <div>
                <span className="text-[8px] uppercase tracking-[0.4em] text-[#d4af37] font-bold block mb-1">Curation</span>
                <h3 className="text-2xl text-white/90 serif italic tracking-tight leading-tight">{image.title}</h3>
            </div>
            <span className="text-[7px] text-gray-500 font-medium uppercase tracking-widest border border-white/5 px-3 py-1 rounded-full">
                {new Date(image.timestamp).toLocaleDateString('ko-KR')}
            </span>
        </div>
        <div className="w-8 h-px bg-[#d4af37]/30 mb-4"></div>
        <p className="text-gray-400 font-light leading-relaxed text-xs italic tracking-wide break-keep opacity-80 group-hover:opacity-100 transition-opacity">
          {image.description}
        </p>
      </div>
    </div>
  );
};
