
import React from 'react';

export const Hero: React.FC = () => {
  // 은은하고 감각적인 자연의 미학 (안개 낀 고요한 숲)
  const bgImage = "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&q=80&w=2000";

  return (
    <section className="relative h-screen flex flex-col items-center justify-center text-center px-4 overflow-hidden">
      {/* Sophisticated Nature Background */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-[40s]" 
        style={{ 
          backgroundImage: `url('${bgImage}')`,
          filter: 'brightness(0.55) contrast(1.1) saturate(0.9)',
          animation: 'slowZoom 60s infinite alternate ease-in-out'
        }}
      ></div>
      
      {/* Natural Atmospheric Overlays */}
      <div className="absolute inset-0 z-0 bg-gradient-to-b from-black/60 via-transparent to-[#0a0a0a]"></div>
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,_rgba(212,175,55,0.08)_0%,_transparent_80%)]"></div>

      <div className="relative z-10 max-w-5xl">
        <div className="animate-fade-in">
          <div className="flex items-center justify-center gap-6 mb-10">
            <div className="w-12 h-[1px] bg-[#d4af37]/40"></div>
            <span className="text-[12px] uppercase tracking-[1.2em] text-[#d4af37] font-bold opacity-80">Organic Luxury</span>
            <div className="w-12 h-[1px] bg-[#d4af37]/40"></div>
          </div>
          
          <h1 className="text-[10vw] md:text-[12rem] serif italic font-light tracking-tighter text-white select-none leading-[0.8] drop-shadow-[0_20px_80px_rgba(0,0,0,0.8)]">
            뚬<span className="gold-text">뚜미</span>
          </h1>
          
          <div className="mt-16 space-y-12">
            <p className="text-2xl md:text-4xl serif italic font-light tracking-[0.15em] text-white/90 max-w-4xl px-10 mx-auto drop-shadow-md leading-relaxed">
              "기요운 민둥이의 <span className="gold-text">볼따구는 진차로 탐스럽다.</span> 이것은 과학이다."
            </p>
            
            <div className="relative h-px w-80 mx-auto overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#d4af37]/60 to-transparent animate-[shimmer_4s_infinite]"></div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Refined Vertical Scroll Indicator */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-8 opacity-40 hover:opacity-100 transition-opacity duration-700">
        <div className="relative w-px h-24 bg-white/10 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1/2 bg-[#d4af37] animate-[scrollLine_2s_infinite_ease-in-out]"></div>
        </div>
        <span className="text-[9px] uppercase tracking-[1.5em] text-white font-medium vertical-text">Explore Nature</span>
      </div>

      <style>{`
        @keyframes slowZoom {
          from { transform: scale(1); }
          to { transform: scale(1.15); }
        }
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes scrollLine {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(200%); }
        }
        .vertical-text {
          writing-mode: vertical-rl;
          text-orientation: mixed;
        }
      `}</style>
    </section>
  );
};
