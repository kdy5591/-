
import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysisResult } from "../types";

export const analyzeImage = async (base64Image: string): Promise<AIAnalysisResult> => {
  // 인스턴스를 함수 내부에서 생성하여 최신 API 키 상태를 보장하고 초기 로딩 오류를 방지합니다.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image.split(',')[1] || base64Image
            }
          },
          {
            text: "당신은 하이엔드 갤러리의 시니어 큐레이터입니다. 이 사진을 분석하여 다음 지침에 따라 한국어로 응답하세요: 1. 제목: 사진의 핵심을 관통하는 세련된 제목 (5단어 이내). 2. 설명: 사진의 구체적인 시각적 특징(빛의 방향, 지배적인 색감, 피사체의 배치와 구도)을 포착하여 우아하고 고급스러운 문체로 작성된 2문장의 설명. 추상적인 표현보다는 실제 사진에서 보이는 미학적 요소를 구체적으로 언급하세요. JSON 형식으로 반환하세요."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING }
          },
          required: ["title", "description"]
        }
      }
    });

    const result = JSON.parse(response.text || '{"title": "미상의 걸작", "description": "시각적 깊이와 정교한 구도가 조화를 이루는 예술적 기록입니다."}');
    return result as AIAnalysisResult;
  } catch (error) {
    console.error("Gemini analysis error:", error);
    return {
      title: "예술적 아카이브",
      description: "찰나의 빛과 섬세한 시선이 머무는 고요한 공간의 기록입니다."
    };
  }
};
