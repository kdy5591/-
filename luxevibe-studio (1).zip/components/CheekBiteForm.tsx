
import React, { useState } from 'react';
import { Mail, Sparkles, Send, Loader2, AlertCircle } from 'lucide-react';

export const CheekBiteForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setStatus('loading');

    try {
      const response = await fetch('https://formspree.io/f/mlgdvqgg', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          email: email,
          message: 'Ttumttumi Cheek Bite Supporter Application'
        })
      });

      if (response.ok) {
        setStatus('success');
        setEmail('');
        setTimeout(() => setStatus('idle'), 5000);
      } else {
        setStatus('error');
      }
    } catch (err) {
      console.error('Form submission error:', err);
      setStatus('error');
    }
  };

  return (
    <section className="relative py-40 px-8 overflow-hidden bg-[#0a0a0a]">
      {/* Gold Glow Accent */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#d4af37]/5 rounded-full blur-[150px] pointer-events-none"></div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <div className="inline-flex items-center justify-center space-x-4 mb-8">
          <div className="w-12 h-px bg-[#d4af37]/30"></div>
          <span className="text-[10px] uppercase tracking-[0.5em] text-[#d4af37] font-bold">The Inner Circle</span>
          <div className="w-12 h-px bg-[#d4af37]/30"></div>
        </div>

        <h2 className="text-5xl md:text-7xl serif italic font-light text-white mb-8 tracking-tight">
          뚬뚜미 <span className="gold-text">볼따구 물을 사람</span>
        </h2>
        
        <p className="text-gray-500 text-sm md:text-lg font-light mb-16 tracking-wide leading-relaxed max-w-2xl mx-auto break-keep italic">
          이 치명적인 귀여움의 서사에 참여하세요. <br/>
          최신 소식과 뚬뚜미의 아방가르드한 일상을 메일함으로 가장 먼저 보내드립니다.
        </p>

        {status === 'success' ? (
          <div className="animate-fade-in py-4">
            <div className="inline-block px-10 py-5 bg-[#d4af37]/10 border border-[#d4af37]/20 rounded-full shadow-[0_0_30px_rgba(212,175,55,0.1)]">
              <p className="text-[#d4af37] text-xs uppercase tracking-widest font-bold">
                Application Received. Welcome to the Archive.
              </p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col md:flex-row gap-4 items-center justify-center max-w-2xl mx-auto">
            <div className="relative w-full group">
              <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
                <Mail className="w-4 h-4 text-gray-600 group-focus-within:text-[#d4af37] transition-colors" />
              </div>
              <input
                type="email"
                required
                disabled={status === 'loading'}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="YOUR EMAIL"
                className="w-full bg-white/5 border border-white/10 rounded-full py-5 pl-14 pr-8 text-xs text-white uppercase tracking-widest focus:outline-none focus:border-[#d4af37]/40 focus:ring-4 focus:ring-[#d4af37]/10 transition-all duration-500 disabled:opacity-50"
              />
            </div>
            <button
              type="submit"
              disabled={status === 'loading'}
              className="w-full md:w-auto whitespace-nowrap px-12 py-5 bg-[#d4af37] text-black text-[10px] font-bold uppercase tracking-[0.4em] rounded-full hover:bg-white transition-all duration-500 shadow-[0_10px_30px_rgba(212,175,55,0.2)] disabled:bg-gray-700 flex items-center justify-center group"
            >
              {status === 'loading' ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>
                  Join Exhibit
                  <Send className="w-3 h-3 ml-3 transform group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </>
              )}
            </button>
          </form>
        )}

        {status === 'error' && (
          <p className="mt-6 text-red-500 text-[10px] uppercase tracking-widest font-bold animate-pulse">
            Submission failed. Please verify and retry.
          </p>
        )}

        <p className="mt-20 text-[8px] text-gray-700 uppercase tracking-[0.5em] font-medium">
          Secure. Private. Elite.
        </p>
      </div>
    </section>
  );
};
