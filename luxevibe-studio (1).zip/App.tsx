
import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { GalleryCard } from './components/GalleryCard';
import { CheekBiteForm } from './components/CheekBiteForm';
import { ProcessSection } from './components/ProcessSection';
import { UploadZone } from './components/UploadZone';
import { ShowcaseImage } from './types';
import { analyzeImage } from './services/geminiService';
import { storage } from './services/storageService';
import { Plus, Sparkles, Upload, Phone } from 'lucide-react';

const App: React.FC = () => {
  const [images, setImages] = useState<ShowcaseImage[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const loadArchive = async () => {
      try {
        const archivedImages = await storage.getAllImages();
        setImages(archivedImages);
      } catch (err) {
        console.error("Failed to load archive:", err);
      } finally {
        setIsInitialLoading(false);
      }
    };
    loadArchive();
  }, []);

  const handleFileUpload = useCallback(async (file: File) => {
    if (!file) return;
    
    setIsAnalyzing(true);
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      const base64Data = e.target?.result as string;
      if (!base64Data) {
        setIsAnalyzing(false);
        return;
      }

      const tempId = 'temp-' + Math.random().toString(36).substr(2, 9);
      const pendingImage: ShowcaseImage = {
        id: tempId,
        url: base64Data,
        title: "큐레이팅 중...",
        description: "AI 큐레이터가 이미지의 미학적 특징을 분석하고 있습니다.",
        timestamp: Date.now()
      };
      
      setImages(prev => [pendingImage, ...prev]);
      
      try {
        const analysis = await analyzeImage(base64Data);
        const finalImage: ShowcaseImage = { 
          ...pendingImage, 
          title: analysis.title, 
          description: analysis.description, 
          id: Math.random().toString(36).substr(2, 9) 
        };
        await storage.saveImage(finalImage);
        setImages(prev => prev.map(img => img.id === tempId ? finalImage : img));
      } catch (err) {
        const fallbackImage: ShowcaseImage = { 
          ...pendingImage, 
          title: "예술적 기록", 
          description: "찰나의 순간을 포착한 감각적인 시각적 기록입니다.", 
          id: Math.random().toString(36).substr(2, 9) 
        };
        await storage.saveImage(fallbackImage);
        setImages(prev => prev.map(img => img.id === tempId ? fallbackImage : img));
      } finally {
        setIsAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  }, []);

  const triggerUpload = () => fileInputRef.current?.click();

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      <Navbar />
      <Hero />
      
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])} 
        accept="image/*" 
        className="hidden" 
      />

      <main className="relative z-10 -mt-24">
        {/* Upload Section */}
        <UploadZone onUpload={handleFileUpload} isAnalyzing={isAnalyzing} />

        {/* Collection Section */}
        <section id="collection" className="px-8 pb-32 max-w-7xl mx-auto">
          {/* Gallery Header */}
          <div className="mb-24 flex flex-col md:flex-row items-end justify-between border-b border-white/5 pb-12">
            <div className="text-center md:text-left mb-8 md:mb-0">
              <h2 className="text-5xl md:text-8xl serif italic font-light mb-6 text-white tracking-tighter">Collection</h2>
              <p className="text-[10px] uppercase tracking-[1em] text-[#d4af37] font-bold opacity-80">예술적 감각의 시각적 서사</p>
            </div>
            
            <button 
              onClick={triggerUpload}
              disabled={isAnalyzing}
              className="group relative flex items-center space-x-4 bg-white/5 hover:bg-[#d4af37] border border-white/10 px-10 py-5 rounded-full shadow-2xl transition-all duration-500 disabled:opacity-50"
            >
              {isAnalyzing ? (
                <Sparkles className="w-4 h-4 text-[#d4af37] animate-spin" />
              ) : (
                <Upload className="w-4 h-4 text-[#d4af37] group-hover:text-black transition-colors" />
              )}
              <span className="text-[10px] uppercase tracking-[0.3em] text-white group-hover:text-black font-bold transition-colors">전시 추가하기</span>
            </button>
          </div>

          <div className="min-h-[600px]">
            {isInitialLoading ? (
              <div className="flex items-center justify-center py-40">
                <div className="w-10 h-10 border-2 border-[#d4af37]/10 border-t-[#d4af37] rounded-full animate-spin"></div>
              </div>
            ) : images.length > 0 ? (
              <div className="columns-1 md:columns-2 lg:columns-3 gap-12">
                {images.map(img => <GalleryCard key={img.id} image={img} />)}
              </div>
            ) : (
              <div className="text-center py-40 border border-dashed border-white/5 rounded-[40px] bg-white/[0.02]">
                <p className="text-gray-600 serif italic text-2xl font-light">아카이브가 비어 있습니다. 첫 번째 영감을 기록해보세요.</p>
              </div>
            )}
          </div>
        </section>

        {/* Brand Story / Methodology */}
        <ProcessSection />
      </main>

      <CheekBiteForm />

      <footer className="bg-black border-t border-white/5 py-24 px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-gray-600 text-[10px] tracking-[0.4em] uppercase font-medium">
          <div className="space-y-4 text-center md:text-left">
            <p className="text-white font-bold opacity-80">&copy; 2024 TTUMTTUMI ARTISTRY.</p>
            <p className="flex items-center justify-center md:justify-start gap-3 text-[#d4af37]">
              <Phone className="w-3 h-3" />
              010 2408 2070
            </p>
          </div>
          <div className="flex space-x-12 mt-12 md:mt-0 serif italic tracking-widest lowercase">
            <a href="#" className="hover:text-white transition-colors">이수미</a>
            <a href="#" className="hover:text-white transition-colors">뚬뚜미</a>
            <a href="#" className="hover:text-white transition-colors">민둥이</a>
          </div>
        </div>
      </footer>

      {/* Aesthetic Floating Action Button */}
      <div className="fixed bottom-12 right-12 z-50">
        <button 
          onClick={triggerUpload}
          disabled={isAnalyzing}
          className={`w-20 h-20 rounded-full shadow-[0_0_50px_rgba(212,175,55,0.2)] flex items-center justify-center transition-all duration-700 group
            ${isAnalyzing ? 'bg-white/10' : 'bg-[#d4af37] hover:scale-110'}
          `}
        >
          {isAnalyzing ? (
            <Sparkles className="w-8 h-8 text-[#d4af37] animate-spin" />
          ) : (
            <Plus className="w-10 h-10 text-black transition-transform group-hover:rotate-90" />
          )}
        </button>
      </div>
    </div>
  );
};

export default App;
